package gsm;

public class SungJuck {
	public int b_num;
	public int b_ban;
	public float kor;
	public float eng;
}
